
package targetas;

 import java.util.Scanner;
public class Targetas {

  
    public static void main(String[] args) {
        Targetas1 i=new Targetas1 ();
        Scanner h=new Scanner (System.in);
        
        
        System.out.println("bienvenido por favor inserte su numero de targeta (debe ser exactamente de 16 digitos)");
        String numero_targeta=h.next();
        i.setNumero_targeta(numero_targeta);
        int valores;
        valores=numero_targeta.length();
        
        
        System.out.println("inserte por favor su nip (solo se permite de 4 digitos , solo numeros)");
        int nip=h.nextInt();
        i.setNip(nip);
        
        System.out.println("favor de ingresar su nombre");
        String nombre=h.next();
        i.setNombre(nombre);
        
        System.out.println("favor de anotar su numero telefonico");
        String telefono ;
        telefono=h.next();
        i.setTelefono(telefono);
     
        
    
        if (valores==16 && nip<10000){
           
            
            int menu;
            do{
            System.out.println (i.toString());
            menu=h.nextInt();
            i.setMenu(menu);
            switch (menu){
                case 1:
             
       
                 float salario;  
                  System.out.println("desea meter saldo a su cuenta (opciones: si =1 y no=2 ");
                 int opcion=h.nextInt();
                  if (opcion==1){
                 System.out.println("ingrese el deposito en su cuenta");
                 salario=h.nextFloat();
                 i.setSalario(salario);
                 }
                  if  (opcion==2){
    
                  System.out.println("actualmente " +  "no cuenta con saldo " + "\n");
                 }
        
                  else {
                   System.out.println("ingrese bien la varibale");
                  }
                    break;
                case 2:
                    System.out.println("num.cuneta" + numero_targeta  + "\nefectitov=0");
                            
                    break;
                case 3:
                    System.out.println("actualmente no cuenta con saldo");
                    
                    
                    
                    
                    break;
                   
                    
                case 4:
                     System.out.println("de acuerdo  al menu elija las opciones que se le favorece" +
                            "\n1.credito ,"
                            + "\n2.seguro");
                    int menu2=h.nextInt();
                    switch (menu2){
                    case 1: 
                        int seguros=0;
                        i.setSeguros(seguros);
                    System.out.println("actualmente cuenta con" + seguros + "\n");
                    break;
                    case 2:
                        int creditos=0;
                        i.setCreditos(creditos);
                        System.out.println("actualmente cuenta con "+ creditos  + "\n");
                        break;
                    default:
                        System.out.println("elija por favor la opcion concedida");
                }
                    
                    break;
                    
                case 5:
                    System.out.println("gracias por elegir el lugar ");
                default:
                    System.out.println("escriba bien un numero ");
                
                
                
            }
            }while (menu!=5);
            
        }
        else {
            System.out.println("diga bien su sormula");
        }
      
        }   
   
}
