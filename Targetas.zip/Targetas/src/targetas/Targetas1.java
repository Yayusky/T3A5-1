
package targetas;

import java.util.Scanner;

public class Targetas1 {
 private String numero_targeta;
 private int nip;
 private String nombre;
 private String telefono;
 private int menu;
 private float salario;
 private int seguros;
 private int creditos;
 private int valores;
 
 public Targetas1 (){}

    public Targetas1(String numero_targeta, int nip, String nombre, String telefono, int menu, float salario, int seguros, int creditos, int valores) {
        this.numero_targeta = numero_targeta;
        this.nip = nip;
        this.nombre = nombre;
        this.telefono = telefono;
        this.menu = menu;
        this.salario = salario;
        this.seguros = seguros;
        this.creditos = creditos;
        this.valores = valores;
    }

    public int getValores() {
        return valores;
    }

    public void setValores(int valores) {
        this.valores = valores;
    }

    public String getNumero_targeta() {
        return numero_targeta;
    }

    public void setNumero_targeta(String numero_targeta) {
        this.numero_targeta = numero_targeta;
    }

    public int getNip() {
        return nip;
    }

    public void setNip(int nip) {
        this.nip = nip;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getMenu() {
        return menu;
    }

    public void setMenu(int menu) {
        this.menu = menu;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public int getSeguros() {
        return seguros;
    }

    public void setSeguros(int seguros) {
        this.seguros = seguros;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    @Override
    public String toString() {
        return "bienvenido " + nombre + " su numero telefonico : " + telefono  + 
                "\npor favor elija una de las opciones para usar el cajero "
                + "\n1.consultar saldo" + "\n2. consultar estado de cuentas" + 
                "\n3.otras opciones" + "\n4.salir";
    }
    
 
    
}
